package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RabbitConsumer2Application {

	public static void main(String[] args) {
		SpringApplication.run(RabbitConsumer2Application.class, args);
	}
}
