package com.example;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitMessagingTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
public class RabbitmqProducerService
{

    private static final Logger logger = LoggerFactory.getLogger(
        RabbitmqProducerService.class);
    @Value("${rabbitmq.queue.message}")
    String messageQueueName;

    @Value("${rabbitmq.exchange.messageexchange}")
    String exchange;

    
    @Autowired
    RabbitMessagingTemplate rabbitMessagingTemplate;


    public void send(String str)
    {


        logger.info("Sending message to rabbit "+str);
         String str1 =rabbitMessagingTemplate.convertSendAndReceive(exchange,
         messageQueueName, str,String.class);
         if(str1!=null)
         logger.info("ACK from consumer:"+str1);
       

    }
}
